sap.ui.define([
	"fioriweatherapp/test/unit/controller/Dashboard.controller"
], function () {
	"use strict";
});
