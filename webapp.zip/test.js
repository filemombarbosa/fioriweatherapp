const portNumber = process.env.port || 9091;

console.log('The tests runner is available at http://localhost:' + portNumber + '/test/unit/unitTests.qunit.html')